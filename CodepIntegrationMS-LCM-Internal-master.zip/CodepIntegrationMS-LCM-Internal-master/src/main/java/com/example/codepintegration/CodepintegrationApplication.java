package com.example.codepintegration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodepintegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodepintegrationApplication.class, args);
	}

}
