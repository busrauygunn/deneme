package com.example.codepintegration.controller;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.UnexpectedJobExecutionException;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;


public class FileDeletingTasklet implements Tasklet, InitializingBean {
    private static final Logger grayLoglogger = Logger.getLogger("graylogLogger");

    private Resource[] resources;
    LocalDate localDate = LocalDate.now();

    public FileDeletingTasklet() {
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        for (Resource r : resources) {
            File file = r.getFile();

            String path = "/appapidata/codeplcm/archiveLcm/";
            //String path = "C:\\Users\\t53802\\workspace\\TOFAS\\Files\\archiveLcm\\";

            File newFile = new File(path + localDate + "_"+ file.getName());
            //System.out.println("DESTINATION####################################" + newFile.toPath());
            //System.out.println("SOURCE####################################" + file.toPath());

            Files.copy(file.toPath(),
                    newFile.toPath(),
                    //Paths.get(path + file.getName()),
                    StandardCopyOption.REPLACE_EXISTING);
            System.out.println("DESTINATION####################################" + newFile.toPath());
            System.out.println("SOURCE####################################" + file.toPath());
            grayLoglogger.info("Dosya başarılı bir şekilde " + path + " e arşivlendi.");

            boolean deleted = file.delete();
            if (!deleted) {
                grayLoglogger.warn("Dosya silenirken bir hata oluştu. Lütfen kontol ediniz!");
                throw new UnexpectedJobExecutionException("Could not delete file " + file.getPath());
            }
            grayLoglogger.info("RPA ile gelen dosya başarılı bir şekilde silindi.");
        }
        return RepeatStatus.FINISHED;
    }

    public void setResources(Resource[] resources) {
        this.resources = resources;
    }

    public void afterPropertiesSet() throws Exception {
        Assert.notNull(resources, "directory must be set");
    }


}
