package com.example.codepintegration.batch;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.core.io.Resource;

public class CustomStepListener implements StepExecutionListener {

    private Resource[] inputResources ;


    public CustomStepListener(Resource[] inputResources){
        this.inputResources = inputResources;
    }

    @Override
    public void beforeStep(StepExecution stepExecution) {
        System.out.println("StepExecutionListener - beforeStep");
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        System.out.println("StepExecutionListener - afterStep");

        return null;
    }

}