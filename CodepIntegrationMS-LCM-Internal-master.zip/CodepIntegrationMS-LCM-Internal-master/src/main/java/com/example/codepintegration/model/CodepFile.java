package com.example.codepintegration.model;

/*
 * @author buygun on 23.09.2021
 */

import javax.persistence.Column;
import javax.persistence.Id;
import java.util.Date;

//@Entity
//@Immutable
//@Table(schema = "TFS_OMM_FDW", name = "CODEP_FILE")
public class CodepFile {

    @Id
    @Column(name = "ID")
    private Long id;
    private String platf;
    private String mod;
    private String odm;
    private String odmDescription;
    private String odmManager;
    private String operator;
    private String operatorManager;
    private String cause;
    private String causeDescription;
    private String spm;
    private String spmIssueDate;
    private String spmApprovalDate;
    private String initiative;
    private String odmToBeEvalued;
    private String odmState;
    private String progress;
    private String updateDate;
    @Column(name = "latest_15_date")
    private String latest15Date;
    @Column(name = "latest_15u_date")
    private String latest15uDate;
    private String dateOfIssue;
    @Column(name = "lates_15b_date")
    private String lates15bDate;
    @Column(name = "lates_16_date")
    private String lates16Date;
    @Column(name = "lates_25_date")
    private String lates25Date;
    @Column(name = "lates_30_date")
    private String lates30Date;
    private String technLock;
    private String economicApprovalDate;
    private String odmClosureDate;
    @Column(name = "lates_15")
    private String lates15;
    @Column(name = "lates_16")
    private String lates16;
    private Long status;
    private String insby;
    private Date insdate;
    private String updby;
    private Date upddate;
    private String recordStatus;
    private String motivation;
    private Date changeDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPlatf() {
        return platf;
    }

    public void setPlatf(String platf) {
        this.platf = platf;
    }

    public String getMod() {
        return mod;
    }

    public void setMod(String mod) {
        this.mod = mod;
    }

    public String getOdm() {
        return odm;
    }

    public void setOdm(String odm) {
        this.odm = odm;
    }

    public String getOdmDescription() {
        return odmDescription;
    }

    public void setOdmDescription(String odmDescription) {
        this.odmDescription = odmDescription;
    }

    public String getOdmManager() {
        return odmManager;
    }

    public void setOdmManager(String odmManager) {
        this.odmManager = odmManager;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getOperatorManager() {
        return operatorManager;
    }

    public void setOperatorManager(String operatorManager) {
        this.operatorManager = operatorManager;
    }

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }

    public String getCauseDescription() {
        return causeDescription;
    }

    public void setCauseDescription(String causeDescription) {
        this.causeDescription = causeDescription;
    }

    public String getSpm() {
        return spm;
    }

    public void setSpm(String spm) {
        this.spm = spm;
    }

    public String getSpmIssueDate() {
        return spmIssueDate;
    }

    public void setSpmIssueDate(String spmIssueDate) {
        this.spmIssueDate = spmIssueDate;
    }

    public String getSpmApprovalDate() {
        return spmApprovalDate;
    }

    public void setSpmApprovalDate(String spmApprovalDate) {
        this.spmApprovalDate = spmApprovalDate;
    }

    public String getInitiative() {
        return initiative;
    }

    public void setInitiative(String initiative) {
        this.initiative = initiative;
    }

    public String getOdmToBeEvalued() {
        return odmToBeEvalued;
    }

    public void setOdmToBeEvalued(String odmToBeEvalued) {
        this.odmToBeEvalued = odmToBeEvalued;
    }

    public String getOdmState() {
        return odmState;
    }

    public void setOdmState(String odmState) {
        this.odmState = odmState;
    }

    public String getProgress() {
        return progress;
    }

    public void setProgress(String progress) {
        this.progress = progress;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getLatest15Date() {
        return latest15Date;
    }

    public void setLatest15Date(String latest15Date) {
        this.latest15Date = latest15Date;
    }

    public String getLatest15uDate() {
        return latest15uDate;
    }

    public void setLatest15uDate(String latest15uDate) {
        this.latest15uDate = latest15uDate;
    }

    public String getDateOfIssue() {
        return dateOfIssue;
    }

    public void setDateOfIssue(String dateOfIssue) {
        this.dateOfIssue = dateOfIssue;
    }

    public String getLates15bDate() {
        return lates15bDate;
    }

    public void setLates15bDate(String lates15bDate) {
        this.lates15bDate = lates15bDate;
    }

    public String getLates16Date() {
        return lates16Date;
    }

    public void setLates16Date(String lates16Date) {
        this.lates16Date = lates16Date;
    }

    public String getLates25Date() {
        return lates25Date;
    }

    public void setLates25Date(String lates25Date) {
        this.lates25Date = lates25Date;
    }

    public String getLates30Date() {
        return lates30Date;
    }

    public void setLates30Date(String lates30Date) {
        this.lates30Date = lates30Date;
    }

    public String getTechnLock() {
        return technLock;
    }

    public void setTechnLock(String technLock) {
        this.technLock = technLock;
    }

    public String getEconomicApprovalDate() {
        return economicApprovalDate;
    }

    public void setEconomicApprovalDate(String economicApprovalDate) {
        this.economicApprovalDate = economicApprovalDate;
    }

    public String getOdmClosureDate() {
        return odmClosureDate;
    }

    public void setOdmClosureDate(String odmClosureDate) {
        this.odmClosureDate = odmClosureDate;
    }

    public String getLates15() {
        return lates15;
    }

    public void setLates15(String lates15) {
        this.lates15 = lates15;
    }

    public String getLates16() {
        return lates16;
    }

    public void setLates16(String lates16) {
        this.lates16 = lates16;
    }

    public Long getStatus() {
        return status;
    }

    public void setStatus(Long status) {
        this.status = status;
    }

    public String getInsby() {
        return insby;
    }

    public void setInsby(String insby) {
        this.insby = insby;
    }

    public Date getInsdate() {
        return insdate;
    }

    public void setInsdate(Date insdate) {
        this.insdate = insdate;
    }

    public String getUpdby() {
        return updby;
    }

    public void setUpdby(String updby) {
        this.updby = updby;
    }

    public Date getUpddate() {
        return upddate;
    }

    public void setUpddate(Date upddate) {
        this.upddate = upddate;
    }

    public String getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(String recordStatus) {
        this.recordStatus = recordStatus;
    }

    public String getMotivation() {
        return motivation;
    }

    public void setMotivation(String motivation) {
        this.motivation = motivation;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    @Override
    public String toString() {
        return "CodepFile{" +
                "id=" + id +
                ", platf='" + platf + '\'' +
                ", mod='" + mod + '\'' +
                ", odm='" + odm + '\'' +
                ", odmDescription='" + odmDescription + '\'' +
                ", odmManager='" + odmManager + '\'' +
                ", operator='" + operator + '\'' +
                ", operatorManager='" + operatorManager + '\'' +
                ", cause='" + cause + '\'' +
                ", causeDescription='" + causeDescription + '\'' +
                ", spm='" + spm + '\'' +
                ", spmIssueDate='" + spmIssueDate + '\'' +
                ", spmApprovalDate='" + spmApprovalDate + '\'' +
                ", initiative='" + initiative + '\'' +
                ", odmToBeEvalued='" + odmToBeEvalued + '\'' +
                ", odmState='" + odmState + '\'' +
                ", progress='" + progress + '\'' +
                ", updateDate='" + updateDate + '\'' +
                ", latest15Date='" + latest15Date + '\'' +
                ", latest15uDate='" + latest15uDate + '\'' +
                ", dateOfIssue='" + dateOfIssue + '\'' +
                ", lates15bDate='" + lates15bDate + '\'' +
                ", lates16Date='" + lates16Date + '\'' +
                ", lates25Date='" + lates25Date + '\'' +
                ", lates30Date='" + lates30Date + '\'' +
                ", technLock='" + technLock + '\'' +
                ", economicApprovalDate='" + economicApprovalDate + '\'' +
                ", odmClosureDate='" + odmClosureDate + '\'' +
                ", lates15='" + lates15 + '\'' +
                ", lates16='" + lates16 + '\'' +
                ", status=" + status +
                ", insby='" + insby + '\'' +
                ", insdate=" + insdate +
                ", updby='" + updby + '\'' +
                ", upddate=" + upddate +
                ", recordStatus='" + recordStatus + '\'' +
                ", motivation='" + motivation + '\'' +
                ", changeDate=" + changeDate +
                '}';
    }
}
