package com.example.codepintegration.repository;

/*
 * @author buygun on 23.09.2021
 */

import com.example.codepintegration.model.CodepFile;

import java.util.List;

public interface CodepFileRepository {
    List<CodepFile> findAllByProgressAndLates25DateAndLates25DateIsNotNull(String progress, String lates25Date);
}
