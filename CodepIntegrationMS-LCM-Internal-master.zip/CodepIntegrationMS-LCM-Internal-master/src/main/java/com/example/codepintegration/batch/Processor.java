package com.example.codepintegration.batch;

import com.example.codepintegration.model.Codep;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class Processor implements ItemProcessor<Codep,Codep> {


    @Override
    public Codep process(Codep codep) throws Exception {
        //System.out.println("Inserting Codep info: " + codep);
        return codep;
    }

}
