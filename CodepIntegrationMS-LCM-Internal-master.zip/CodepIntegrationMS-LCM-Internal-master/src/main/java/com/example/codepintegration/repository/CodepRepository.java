package com.example.codepintegration.repository;

import com.example.codepintegration.model.Codep;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface CodepRepository extends JpaRepository<Codep,String> {

    //Model
    //ODM no
    //ResimNo-partno
    //Matricola

    // Codep findByModelAndOdmNoAndPartNrAndPartMatr(Long model, Long odmNo, String partNr, String partMatr);
    Codep findByModelAndOdmNoAndPartNr(String model, String odmNo, String partNr);

    List<Codep> findAllByModelAndOdmNo(String mod, String odm);


    //Codep findByModel();
}
