package com.example.codepintegration.config;

import com.example.codepintegration.batch.CustomStepListener;
import com.example.codepintegration.batch.JobExecutionManager;
import com.example.codepintegration.controller.FileDeletingTasklet;
import com.example.codepintegration.model.Codep;
import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.MultiResourceItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

@Configuration
@EnableBatchProcessing
public class SpringBatchConfig {
    private static final Logger grayLogLogger = Logger.getLogger("graylogLogger");

    private FileDeletingTasklet task = new FileDeletingTasklet();
/*
    @Bean
    public TaskExecutor taskExecutor(){
        SimpleAsyncTaskExecutor asyncTaskExecutor=new SimpleAsyncTaskExecutor("spring_batch_yusuf");
        asyncTaskExecutor.setConcurrencyLimit(20);
        return asyncTaskExecutor;
    }*/

    @Bean
    public Job job(JobBuilderFactory jobBuilderFactory,
                   StepBuilderFactory stepBuilderFactory,
                   ItemReader<Codep> itemReader,
                   ItemProcessor<Codep, Codep> itemProcessor,
                   ItemWriter<Codep> itemWriter,
                   //@Value("file:C:/Users/t53802/workspace/TOFAS/Files/*.txt") Resource[] inputResources) {
                    @Value("file:/appapidata/codeplcm/*.txt") Resource[] inputResources) {

        Step step = stepBuilderFactory.get("readTxtFileStep")
                .<Codep, Codep>chunk(200)
                //.reader(itemReader)
                .reader(multiResourceItemReader(null))
                .processor(itemProcessor)
                .writer(itemWriter)
                .faultTolerant()
                .skipLimit(5000)
                .skip(Exception.class)
                //.taskExecutor(taskExecutor())
                .build();
        grayLogLogger.info("CODEP coming file reading step done successfully.");


        task.setResources(inputResources);

        Step step2 = stepBuilderFactory.get("deleteTxtFileStep")
                .tasklet(task)
                .allowStartIfComplete(true)
                //.listener(CustomStepListener(inputResources))
                .build();


        Job job = jobBuilderFactory.get("readCodepFilesJob")
                .incrementer(new RunIdIncrementer())
                .start(step)
                .next(step2)
                .listener(JobExecutionManager(inputResources))
                .build();
        grayLogLogger.info("Job successfully finished all steps.");

        return job;
    }

    private JobExecutionListener JobExecutionManager(Resource[] inputResources) {
        return new JobExecutionManager(inputResources);
    }

    private StepExecutionListener CustomStepListener(Resource[] inputResources) {
        return new CustomStepListener(inputResources);
    }

    @Bean
    @JobScope
    //public MultiResourceItemReader<Codep> multiResourceItemReader(@Value("file:C:/Users/t53802/workspace/TOFAS/Files/*.txt") Resource[] inputResources) {
    public MultiResourceItemReader<Codep> multiResourceItemReader(@Value("file:/appapidata/codeplcm/*.txt") Resource[] inputResources) {

        MultiResourceItemReader<Codep> resourceItemReader = new MultiResourceItemReader<>();

        resourceItemReader.setResources(inputResources);
        task.setResources(inputResources);
        resourceItemReader.setDelegate(itemReader());
        return resourceItemReader;
    }


    @Bean
    public FlatFileItemReader<Codep> itemReader() {

        FlatFileItemReader<Codep> flatFileItemReader = new FlatFileItemReader<>();
        flatFileItemReader.setName("TXT-Reader");
        //flatFileItemReader.setEncoding("ISO-8859-9");
        flatFileItemReader.setLineMapper(lineMapper());
        //flatFileItemReader.setLinesToSkip(1);
        //flatFileItemReader.afterPropertiesSet();
        //flatFileItemReader.open(new ExecutionContext());
        return flatFileItemReader;
    }

    @Bean
    public LineMapper<Codep> lineMapper() {
        DefaultLineMapper<Codep> defaultLineMapper = new DefaultLineMapper<>();
        DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();


        lineTokenizer.setDelimiter("|");
        lineTokenizer.setQuoteCharacter('$');
        lineTokenizer.setStrict(false);
        lineTokenizer.setNames(new String[]{"model", "odmNo", "odmDesc", "odmReason", "issueDate", "spm", "partNr", "partDesc", "partMatr",
                "pcCode", "pcDesc", "funcCode", "funcDesc", "subsystem", "subsysDesc", "system", "systemDesc", "modelType", "fmt", "cad", "state",
                "lock", "urgent", "odmFlag", "partChangeType", "partChangeDesc", "changeTypeCode", "changeType",
                "changeTypeDesc", "pair", "activation", "zeroDate", "fifteenDate", "fifteenBDate", "fifteenUDate",
                "sixteenDate", "twentyFiveDate", "thirtyDate", "partAtrFlag", "realStrucFlag", "drawingFlag", "sheetsFlag", "metarialsFlag",
                "usageAttFlag", "modelImpByOdm", "impactFlag", "operator", "operatorManager", "odmRequester", "unitCode", "unitDescription",
                "initiativeCode", "drawing", "drawingRelease", "releaseDate"
        });


        BeanWrapperFieldSetMapper<Codep> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
        fieldSetMapper.setTargetType(Codep.class);


        defaultLineMapper.setLineTokenizer(lineTokenizer);
        defaultLineMapper.setFieldSetMapper(fieldSetMapper);

        return defaultLineMapper;
    }

}
