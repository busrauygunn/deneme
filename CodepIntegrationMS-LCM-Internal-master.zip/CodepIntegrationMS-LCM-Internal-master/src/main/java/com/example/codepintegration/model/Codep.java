package com.example.codepintegration.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Codep {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String model;
    private String odmNo;
    private String odmDesc;
    private String odmReason;
    private String issueDate;
    private String spm;
    private String partNr;
    private String partDesc;
    private String partMatr;
    private String pcCode;
    private String pcDesc;
    private String funcCode;
    private String funcDesc;
    private String subsystem;
    private String subsysDesc;
    private String system;
    private String systemDesc;
    private String modelType;
    private String fmt;
    private String cad;
    private String state;
    private String lock;
    private String urgent;
    private String odmFlag;
    private String partChangeType;
    private String partChangeDesc;
    private String changeTypeCode;
    private String changeType;
    private String changeTypeDesc;
    private String pair;
    private String activation;
    private String zeroDate;
    private String fifteenDate;
    private String fifteenBDate;
    private String fifteenUDate;
    private String sixteenDate;
    private String twentyFiveDate;
    private String thirtyDate;
    private String partAtrFlag;
    private String realStrucFlag;
    private String drawingFlag;
    private String sheetsFlag;
    private String materialsFlag;
    private String usageAttFlag;
    private String modelImpByOdm;
    private String impactFlag;
    private String operator;
    private String operatorManager;
    private String odmRequester;
    private String unitCode;
    private String unitDescription;
    private String initiativeCode;
    private String drawing;
    private String drawingRelease;
    private String releaseDate;
    private Boolean deletedFlag;

    public Codep() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getOdmNo() {
        return odmNo;
    }

    public void setOdmNo(String odmNo) {
        this.odmNo = odmNo;
    }

    public String getOdmDesc() {
        return odmDesc;
    }

    public void setOdmDesc(String odmDesc) {
        this.odmDesc = odmDesc;
    }

    public String getOdmReason() {
        return odmReason;
    }

    public void setOdmReason(String odmReason) {
        this.odmReason = odmReason;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    public String getSpm() {
        return spm;
    }

    public void setSpm(String spm) {
        this.spm = spm;
    }

    public String getPartNr() {
        return partNr;
    }

    public void setPartNr(String partNr) {
        this.partNr = partNr;
    }

    public String getPartDesc() {
        return partDesc;
    }

    public void setPartDesc(String partDesc) {
        this.partDesc = partDesc;
    }

    public String getPartMatr() {
        return partMatr;
    }

    public void setPartMatr(String partMatr) {
        this.partMatr = partMatr;
    }

    public String getPcCode() {
        return pcCode;
    }

    public void setPcCode(String pcCode) {
        this.pcCode = pcCode;
    }

    public String getPcDesc() {
        return pcDesc;
    }

    public void setPcDesc(String pcDesc) {
        this.pcDesc = pcDesc;
    }

    public String getFuncCode() {
        return funcCode;
    }

    public void setFuncCode(String funcCode) {
        this.funcCode = funcCode;
    }

    public String getFuncDesc() {
        return funcDesc;
    }

    public void setFuncDesc(String funcDesc) {
        this.funcDesc = funcDesc;
    }

    public String getSubsystem() {
        return subsystem;
    }

    public void setSubsystem(String subsystem) {
        this.subsystem = subsystem;
    }

    public String getSubsysDesc() {
        return subsysDesc;
    }

    public void setSubsysDesc(String subsysDesc) {
        this.subsysDesc = subsysDesc;
    }

    public String getSystem() {
        return system;
    }

    public void setSystem(String system) {
        this.system = system;
    }

    public String getSystemDesc() {
        return systemDesc;
    }

    public void setSystemDesc(String systemDesc) {
        this.systemDesc = systemDesc;
    }

    public String getModelType() {
        return modelType;
    }

    public void setModelType(String modelType) {
        this.modelType = modelType;
    }

    public String getFmt() {
        return fmt;
    }

    public void setFmt(String fmt) {
        this.fmt = fmt;
    }

    public String getCad() {
        return cad;
    }

    public void setCad(String cad) {
        this.cad = cad;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getLock() {
        return lock;
    }

    public void setLock(String lock) {
        this.lock = lock;
    }

    public String getUrgent() {
        return urgent;
    }

    public void setUrgent(String urgent) {
        this.urgent = urgent;
    }

    public String getOdmFlag() {
        return odmFlag;
    }

    public void setOdmFlag(String odmFlag) {
        this.odmFlag = odmFlag;
    }

    public String getPartChangeType() {
        return partChangeType;
    }

    public void setPartChangeType(String partChangeType) {
        this.partChangeType = partChangeType;
    }

    public String getPartChangeDesc() {
        return partChangeDesc;
    }

    public void setPartChangeDesc(String partChangeDesc) {
        this.partChangeDesc = partChangeDesc;
    }

    public String getChangeTypeCode() {
        return changeTypeCode;
    }

    public void setChangeTypeCode(String changeTypeCode) {
        this.changeTypeCode = changeTypeCode;
    }

    public String getChangeType() {
        return changeType;
    }

    public void setChangeType(String changeType) {
        this.changeType = changeType;
    }

    public String getChangeTypeDesc() {
        return changeTypeDesc;
    }

    public void setChangeTypeDesc(String changeTypeDesc) {
        this.changeTypeDesc = changeTypeDesc;
    }

    public String getPair() {
        return pair;
    }

    public void setPair(String pair) {
        this.pair = pair;
    }

    public String getActivation() {
        return activation;
    }

    public void setActivation(String activation) {
        this.activation = activation;
    }

    public String getZeroDate() {
        return zeroDate;
    }

    public void setZeroDate(String zeroDate) {
        this.zeroDate = zeroDate;
    }

    public String getFifteenDate() {
        return fifteenDate;
    }

    public void setFifteenDate(String fifteenDate) {
        this.fifteenDate = fifteenDate;
    }

    public String getFifteenBDate() {
        return fifteenBDate;
    }

    public void setFifteenBDate(String fifteenBDate) {
        this.fifteenBDate = fifteenBDate;
    }

    public String getFifteenUDate() {
        return fifteenUDate;
    }

    public void setFifteenUDate(String fifteenUDate) {
        this.fifteenUDate = fifteenUDate;
    }

    public String getSixteenDate() {
        return sixteenDate;
    }

    public void setSixteenDate(String sixteenDate) {
        this.sixteenDate = sixteenDate;
    }

    public String getTwentyFiveDate() {
        return twentyFiveDate;
    }

    public void setTwentyFiveDate(String twentyFiveDate) {
        this.twentyFiveDate = twentyFiveDate;
    }

    public String getThirtyDate() {
        return thirtyDate;
    }

    public void setThirtyDate(String thirtyDate) {
        this.thirtyDate = thirtyDate;
    }

    public String getPartAtrFlag() {
        return partAtrFlag;
    }

    public void setPartAtrFlag(String partAtrFlag) {
        this.partAtrFlag = partAtrFlag;
    }

    public String getRealStrucFlag() {
        return realStrucFlag;
    }

    public void setRealStrucFlag(String realStrucFlag) {
        this.realStrucFlag = realStrucFlag;
    }

    public String getDrawingFlag() {
        return drawingFlag;
    }

    public void setDrawingFlag(String drawingFlag) {
        this.drawingFlag = drawingFlag;
    }

    public String getSheetsFlag() {
        return sheetsFlag;
    }

    public void setSheetsFlag(String sheetsFlag) {
        this.sheetsFlag = sheetsFlag;
    }

    public String getMaterialsFlag() {
        return materialsFlag;
    }

    public void setMaterialsFlag(String materialsFlag) {
        this.materialsFlag = materialsFlag;
    }

    public String getUsageAttFlag() {
        return usageAttFlag;
    }

    public void setUsageAttFlag(String usageAttFlag) {
        this.usageAttFlag = usageAttFlag;
    }

    public String getModelImpByOdm() {
        return modelImpByOdm;
    }

    public void setModelImpByOdm(String modelImpByOdm) {
        this.modelImpByOdm = modelImpByOdm;
    }

    public String getImpactFlag() {
        return impactFlag;
    }

    public void setImpactFlag(String impactFlag) {
        this.impactFlag = impactFlag;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getOperatorManager() {
        return operatorManager;
    }

    public void setOperatorManager(String operatorManager) {
        this.operatorManager = operatorManager;
    }

    public String getOdmRequester() {
        return odmRequester;
    }

    public void setOdmRequester(String odmRequester) {
        this.odmRequester = odmRequester;
    }

    public String getUnitCode() {
        return unitCode;
    }

    public void setUnitCode(String unitCode) {
        this.unitCode = unitCode;
    }

    public String getUnitDescription() {
        return unitDescription;
    }

    public void setUnitDescription(String unitDescription) {
        this.unitDescription = unitDescription;
    }

    public String getInitiativeCode() {
        return initiativeCode;
    }

    public void setInitiativeCode(String initiativeCode) {
        this.initiativeCode = initiativeCode;
    }

    public String getDrawing() {
        return drawing;
    }

    public void setDrawing(String drawing) {
        this.drawing = drawing;
    }

    public String getDrawingRelease() {
        return drawingRelease;
    }

    public void setDrawingRelease(String drawingRelease) {
        this.drawingRelease = drawingRelease;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public Boolean getDeletedFlag() {
        return deletedFlag;
    }

    public void setDeletedFlag(Boolean deletedFlag) {
        this.deletedFlag = deletedFlag;
    }

    @Override
    public String toString() {
        return "Codep{" +
                "id=" + id +
                ", model='" + model + '\'' +
                ", odmNo='" + odmNo + '\'' +
                ", odmDesc='" + odmDesc + '\'' +
                ", odmReason='" + odmReason + '\'' +
                ", issueDate='" + issueDate + '\'' +
                ", spm='" + spm + '\'' +
                ", partNr='" + partNr + '\'' +
                ", partDesc='" + partDesc + '\'' +
                ", partMatr='" + partMatr + '\'' +
                ", pcCode='" + pcCode + '\'' +
                ", pcDesc='" + pcDesc + '\'' +
                ", funcCode='" + funcCode + '\'' +
                ", funcDesc='" + funcDesc + '\'' +
                ", subsystem='" + subsystem + '\'' +
                ", subsysDesc='" + subsysDesc + '\'' +
                ", system='" + system + '\'' +
                ", systemDesc='" + systemDesc + '\'' +
                ", modelType='" + modelType + '\'' +
                ", fmt='" + fmt + '\'' +
                ", cad='" + cad + '\'' +
                ", state='" + state + '\'' +
                ", lock='" + lock + '\'' +
                ", urgent='" + urgent + '\'' +
                ", odmFlag='" + odmFlag + '\'' +
                ", partChangeType='" + partChangeType + '\'' +
                ", partChangeDesc='" + partChangeDesc + '\'' +
                ", changeTypeCode='" + changeTypeCode + '\'' +
                ", changeType='" + changeType + '\'' +
                ", changeTypeDesc='" + changeTypeDesc + '\'' +
                ", pair='" + pair + '\'' +
                ", activation='" + activation + '\'' +
                ", zeroDate='" + zeroDate + '\'' +
                ", fifteenDate='" + fifteenDate + '\'' +
                ", fifteenBDate='" + fifteenBDate + '\'' +
                ", fifteenUDate='" + fifteenUDate + '\'' +
                ", sixteenDate='" + sixteenDate + '\'' +
                ", twentyFiveDate='" + twentyFiveDate + '\'' +
                ", thirtyDate='" + thirtyDate + '\'' +
                ", partAtrFlag='" + partAtrFlag + '\'' +
                ", realStrucFlag='" + realStrucFlag + '\'' +
                ", drawingFlag='" + drawingFlag + '\'' +
                ", sheetsFlag='" + sheetsFlag + '\'' +
                ", materialsFlag='" + materialsFlag + '\'' +
                ", usageAttFlag='" + usageAttFlag + '\'' +
                ", modelImpByOdm='" + modelImpByOdm + '\'' +
                ", impactFlag='" + impactFlag + '\'' +
                ", operator='" + operator + '\'' +
                ", operatorManager='" + operatorManager + '\'' +
                ", odmRequester='" + odmRequester + '\'' +
                ", unitCode='" + unitCode + '\'' +
                ", unitDescription='" + unitDescription + '\'' +
                ", initiativeCode='" + initiativeCode + '\'' +
                ", drawing='" + drawing + '\'' +
                ", drawingRelease='" + drawingRelease + '\'' +
                ", releaseDate='" + releaseDate + '\'' +
                ", deletedFlag=" + deletedFlag +
                '}';
    }
}
