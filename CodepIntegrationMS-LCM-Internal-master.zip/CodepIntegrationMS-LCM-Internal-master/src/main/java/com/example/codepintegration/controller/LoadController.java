package com.example.codepintegration.controller;

import org.apache.log4j.Logger;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/load")
//@Component
//@EnableScheduling
public class LoadController {
    private static final Logger grayLogLogger = Logger.getLogger("graylogLogger");

    @Autowired
    JobLauncher jobLauncher;

    @Autowired
    Job job;


    @GetMapping
    // @Scheduled(cron = "0 */2 * ? * *")
    // public BatchStatus load() throws JobParametersInvalidException, JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException {
    public BatchStatus load(){
        //JobParameters jobParameters = new JobParametersBuilder().addLong("time",System.currentTimeMillis()).toJobParameters();

        Map<String, JobParameter> maps = new HashMap<>();
        maps.put("time", new JobParameter(System.currentTimeMillis()));
        JobParameters parameters = new JobParameters(maps);
        JobExecution jobExecution = null;
        try {
            grayLogLogger.info("Codep veri entegrasyonu" + " " + new Date(System.currentTimeMillis()) + " tarihinde başladı.");
            jobExecution = jobLauncher.run(job, parameters);
            grayLogLogger.info("Job's Status:::: " + jobExecution.getStatus() + " Time:" + new Date(System.currentTimeMillis()));
            System.out.println("Job's Status:::: " + jobExecution.getStatus() + " Time:" + new Date(System.currentTimeMillis()));
        } catch (JobExecutionAlreadyRunningException e) {
            grayLogLogger.warn("Job Execution Already Running Exception");
            e.printStackTrace();
        } catch (JobRestartException e) {
            grayLogLogger.warn("Job Restart Exception");
            e.printStackTrace();
        } catch (JobInstanceAlreadyCompleteException e) {
            grayLogLogger.warn("Job Instance Already Complete Exception");
            e.printStackTrace();
        } catch (JobParametersInvalidException e) {
            grayLogLogger.warn("Job Parameters Invalid Exception");
            e.printStackTrace();
        }
        grayLogLogger.info("JobExecution:::: " + jobExecution.getStatus());
        System.out.println("JobExecution:::: " + jobExecution.getStatus());


        System.out.println("Batch is Running...");
        while (jobExecution.isRunning()) {
            System.out.println("...");
        }

        return jobExecution.getStatus();
    }
}
