package com.example.codepintegration.batch;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.core.io.Resource;

public class JobExecutionManager extends JobExecutionListenerSupport {

    private Resource[] inputResources;

    public JobExecutionManager(Resource[] inputResources){
        this.inputResources = inputResources;
    }

    public void afterJob(JobExecution jobExecution) {
        System.out.println("AFTER JOB");
    }

    public void beforeJob(JobExecution jobExecution) {
        System.out.println("BEFORE JOB");
    }


}