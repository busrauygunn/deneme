package com.example.codepintegration.batch;

import com.example.codepintegration.model.Codep;
import com.example.codepintegration.repository.CodepRepository;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;


@Component
public class DBWriter implements ItemWriter<Codep> {

    @Value("${endpoint.sendMailWithToArray}")
    String sendMailWithToArray;

    @Value("${endpoint.sendMailWithCcAndToArray}")
    String sendMailWithCcAndToArray;

    @Value("${endpoint.odmTimePlan}")
    String odmTimePlanEndpoint;

    private static final Logger grayLogLogger = Logger.getLogger("graylogLogger");

    @Autowired
    private CodepRepository codepRepository;

//    @Autowired
//    private CodepFileRepository codepFileRepository;

    @Override
    public void write(List<? extends Codep> codeps) throws Exception {

        //System.out.println("Data saved for codep data: " + codeps);
        //codepRepository.saveAll(codeps);

        //Model
        //ODM no
        //ResimNo-partno
        //trim null empty control is necessary or not?

//        List<Codep> sendMailListForCodep = new ArrayList<>();

        codeps.forEach(newCodep -> {
            if (null != newCodep.getModel() && null != newCodep.getOdmNo() && null != newCodep.getPartNr()) {
                Codep oldCodep = codepRepository.findByModelAndOdmNoAndPartNr(newCodep.getModel(), newCodep.getOdmNo(), newCodep.getPartNr());
                if (null != oldCodep) {
                    if (oldCodep.getModel().equals(newCodep.getModel()) && oldCodep.getOdmNo().equals(newCodep.getOdmNo()) && oldCodep.getPartNr().equals(newCodep.getPartNr())) {
                        if (null != oldCodep.getOdmDesc()) {
                            if (!oldCodep.getOdmDesc().equals(newCodep.getOdmDesc())) {
                                oldCodep.setOdmDesc(newCodep.getOdmDesc());
                            }
                        } else {
                            if (null != newCodep.getOdmDesc()) {
                                oldCodep.setOdmDesc(newCodep.getOdmDesc());
                            }
                        }

                        if (null != oldCodep.getOdmReason()) {
                            if (!oldCodep.getOdmReason().equals(newCodep.getOdmReason())) {
                                oldCodep.setOdmReason(newCodep.getOdmReason());
                            }
                        } else {
                            if (null != newCodep.getOdmReason()) {
                                oldCodep.setOdmReason(newCodep.getOdmReason());
                            }
                        }

                        if (null != oldCodep.getIssueDate()) {
                            if (!oldCodep.getIssueDate().equals(newCodep.getIssueDate())) {
                                oldCodep.setIssueDate(newCodep.getIssueDate());
                            }
                        } else {
                            if (null != newCodep.getIssueDate()) {
                                oldCodep.setIssueDate(newCodep.getIssueDate());
                            }
                        }

                        if (null != oldCodep.getSpm()) {
                            if (!oldCodep.getSpm().equals(newCodep.getSpm())) {
                                oldCodep.setSpm(newCodep.getSpm());
                            }
                        } else {
                            if (null != newCodep.getSpm()) {
                                oldCodep.setSpm(newCodep.getSpm());
                            }
                        }

                        if (null != oldCodep.getPartDesc()) {
                            if (!oldCodep.getPartDesc().equals(newCodep.getPartDesc())) {
                                oldCodep.setPartDesc(newCodep.getPartDesc());
                            }
                        } else {
                            if (null != newCodep.getPartDesc()) {
                                oldCodep.setPartDesc(newCodep.getPartDesc());
                            }
                        }

                        if (null != oldCodep.getPartMatr()) {
                            if (!oldCodep.getPartMatr().equals(newCodep.getPartMatr())) {
                                oldCodep.setPartMatr(newCodep.getPartMatr());
                            }
                        } else {
                            if (null != newCodep.getPartMatr()) {
                                oldCodep.setPartMatr(newCodep.getPartMatr());
                            }
                        }

                        if (null != oldCodep.getPcCode()) {
                            if (!oldCodep.getPcCode().equals(newCodep.getPcCode())) {
                                oldCodep.setPcCode(newCodep.getPcCode());
                            }
                        } else {
                            if (null != newCodep.getPcCode()) {
                                oldCodep.setPcCode(newCodep.getPcCode());
                            }
                        }

                        if (null != oldCodep.getPcDesc()) {
                            if (!oldCodep.getPcDesc().equals(newCodep.getPcDesc())) {
                                oldCodep.setPcDesc(newCodep.getPcDesc());
                            }
                        } else {
                            if (null != newCodep.getPcDesc()) {
                                oldCodep.setPcDesc(newCodep.getPcDesc());
                            }
                        }

                        if (null != oldCodep.getFuncCode()) {
                            if (!oldCodep.getFuncCode().equals(newCodep.getFuncCode())) {
                                oldCodep.setFuncCode(newCodep.getFuncCode());
                            }
                        } else {
                            if (null != newCodep.getFuncCode()) {
                                oldCodep.setFuncCode(newCodep.getFuncCode());
                            }
                        }

                        if (null != oldCodep.getFuncDesc()) {
                            if (!oldCodep.getFuncDesc().equals(newCodep.getFuncDesc())) {
                                oldCodep.setFuncDesc(newCodep.getFuncDesc());
                            }
                        } else {
                            if (null != newCodep.getFuncDesc()) {
                                oldCodep.setFuncDesc(newCodep.getFuncDesc());
                            }
                        }

                        if (null != oldCodep.getSubsystem()) {
                            if (!oldCodep.getSubsystem().equals(newCodep.getSubsystem())) {
                                oldCodep.setSubsystem(newCodep.getSubsystem());
                            }
                        } else {
                            if (null != newCodep.getSubsystem()) {
                                oldCodep.setSubsystem(newCodep.getSubsystem());
                            }
                        }

                        if (null != oldCodep.getSubsysDesc()) {
                            if (!oldCodep.getSubsysDesc().equals(newCodep.getSubsysDesc())) {
                                oldCodep.setSubsysDesc(newCodep.getSubsysDesc());
                            }
                        } else {
                            if (null != newCodep.getSubsysDesc()) {
                                oldCodep.setSubsysDesc(newCodep.getSubsysDesc());
                            }
                        }

                        if (null != oldCodep.getSystem()) {
                            if (!oldCodep.getSystem().equals(newCodep.getSystem())) {
                                oldCodep.setSystem(newCodep.getSystem());
                            }
                        } else {
                            if (null != newCodep.getSystem()) {
                                oldCodep.setSystem(newCodep.getSystem());
                            }
                        }

                        if (null != oldCodep.getSystemDesc()) {
                            if (!oldCodep.getSystemDesc().equals(newCodep.getSystemDesc())) {
                                oldCodep.setSystemDesc(newCodep.getSystemDesc());
                            }
                        } else {
                            if (null != newCodep.getSystemDesc()) {
                                oldCodep.setSystemDesc(newCodep.getSystemDesc());
                            }
                        }

                        if (null != oldCodep.getModelType()) {
                            if (!oldCodep.getModelType().equals(newCodep.getModelType())) {
                                oldCodep.setModelType(newCodep.getModelType());
                            }
                        } else {
                            if (null != newCodep.getModelType()) {
                                oldCodep.setModelType(newCodep.getModelType());
                            }
                        }

                        if (null != oldCodep.getFmt()) {
                            if (!oldCodep.getFmt().equals(newCodep.getFmt())) {
                                oldCodep.setFmt(newCodep.getFmt());
                            }
                        } else {
                            if (null != newCodep.getFmt()) {
                                oldCodep.setFmt(newCodep.getFmt());
                            }
                        }

                        if (null != oldCodep.getCad()) {
                            if (!oldCodep.getCad().equals(newCodep.getCad())) {
                                oldCodep.setCad(newCodep.getCad());
                            }
                        } else {
                            if (null != newCodep.getCad()) {
                                oldCodep.setCad(newCodep.getCad());
                            }
                        }

                        if (null != oldCodep.getState()) {
                            if (!oldCodep.getState().equals(newCodep.getState())) {
                                oldCodep.setState(newCodep.getState());
                            }
                        } else {
                            if (null != newCodep.getState()) {
                                oldCodep.setState(newCodep.getState());
                            }
                        }

                        if (null != oldCodep.getLock()) {
                            if (!oldCodep.getLock().equals(newCodep.getLock())) {
                                oldCodep.setLock(newCodep.getLock());
                            }
                        } else {
                            if (null != newCodep.getLock()) {
                                oldCodep.setLock(newCodep.getLock());
                            }
                        }

                        if (null != oldCodep.getUrgent()) {
                            if (!oldCodep.getUrgent().equals(newCodep.getUrgent())) {
                                oldCodep.setUrgent(newCodep.getUrgent());
                            }
                        } else {
                            if (null != newCodep.getUrgent()) {
                                oldCodep.setUrgent(newCodep.getUrgent());
                            }
                        }

                        if (null != oldCodep.getOdmFlag()) {
                            if (!oldCodep.getOdmFlag().equals(newCodep.getOdmFlag())) {
                                oldCodep.setOdmFlag(newCodep.getOdmFlag());
                            }
                        } else {
                            if (null != newCodep.getOdmFlag()) {
                                oldCodep.setOdmFlag(newCodep.getOdmFlag());
                            }
                        }

                        if (null != oldCodep.getPartChangeType()) {
                            if (!oldCodep.getPartChangeType().equals(newCodep.getPartChangeType())) {
                                oldCodep.setPartChangeType(newCodep.getPartChangeType());
                            }
                        } else {
                            if (null != newCodep.getPartChangeType()) {
                                oldCodep.setPartChangeType(newCodep.getPartChangeType());
                            }
                        }

                        if (null != oldCodep.getPartChangeDesc()) {
                            if (!oldCodep.getPartChangeDesc().equals(newCodep.getPartChangeDesc())) {
                                oldCodep.setPartChangeDesc(newCodep.getPartChangeDesc());
                            }
                        } else {
                            if (null != newCodep.getPartChangeDesc()) {
                                oldCodep.setPartChangeDesc(newCodep.getPartChangeDesc());
                            }
                        }

                        if (null != oldCodep.getChangeTypeCode()) {
                            if (!oldCodep.getChangeTypeCode().equals(newCodep.getChangeTypeCode())) {
                                oldCodep.setChangeTypeCode(newCodep.getChangeTypeCode());
                            }
                        } else {
                            if (null != newCodep.getChangeTypeCode()) {
                                oldCodep.setChangeTypeCode(newCodep.getChangeTypeCode());
                            }
                        }

                        if (null != oldCodep.getChangeType()) {
                            if (!oldCodep.getChangeType().equals(newCodep.getChangeType())) {
                                oldCodep.setChangeType(newCodep.getChangeType());
                            }
                        } else {
                            if (null != newCodep.getChangeType()) {
                                oldCodep.setChangeType(newCodep.getChangeType());
                            }
                        }

                        if (null != oldCodep.getChangeTypeDesc()) {
                            if (!oldCodep.getChangeTypeDesc().equals(newCodep.getChangeTypeDesc())) {
                                oldCodep.setChangeTypeDesc(newCodep.getChangeTypeDesc());
                            }
                        } else {
                            if (null != newCodep.getChangeTypeDesc()) {
                                oldCodep.setChangeTypeDesc(newCodep.getChangeTypeDesc());
                            }
                        }

                        if (null != oldCodep.getPair()) {
                            if (!oldCodep.getPair().equals(newCodep.getPair())) {
                                oldCodep.setPair(newCodep.getPair());
                            }
                        } else {
                            if (null != newCodep.getPair()) {
                                oldCodep.setPair(newCodep.getPair());
                            }
                        }

                        if (null != oldCodep.getActivation()) {
                            if (!oldCodep.getActivation().equals(newCodep.getActivation())) {
                                oldCodep.setActivation(newCodep.getActivation());
                            }
                        } else {
                            if (null != newCodep.getActivation()) {
                                oldCodep.setActivation(newCodep.getActivation());
                            }
                        }

                        if (null != oldCodep.getZeroDate()) {
                            if (!oldCodep.getZeroDate().equals(newCodep.getZeroDate())) {
                                oldCodep.setZeroDate(newCodep.getZeroDate());
                            }
                        } else {
                            if (null != newCodep.getZeroDate()) {
                                oldCodep.setZeroDate(newCodep.getZeroDate());
                            }
                        }

                        if (null != oldCodep.getFifteenDate()) {
                            if (!oldCodep.getFifteenDate().equals(newCodep.getFifteenDate())) {
                                oldCodep.setFifteenDate(newCodep.getFifteenDate());
                            }
                        } else {
                            if (null != newCodep.getFifteenDate()) {
                                oldCodep.setFifteenDate(newCodep.getFifteenDate());
                            }
                        }

                        if (null != oldCodep.getFifteenBDate()) {
                            if (!oldCodep.getFifteenBDate().equals(newCodep.getFifteenBDate())) {
                                oldCodep.setFifteenBDate(newCodep.getFifteenBDate());
                            }
                        } else {
                            if (null != newCodep.getFifteenBDate()) {
                                oldCodep.setFifteenBDate(newCodep.getFifteenBDate());
                            }
                        }

                        if (null != oldCodep.getFifteenUDate()) {
                            if (!oldCodep.getFifteenUDate().equals(newCodep.getFifteenUDate())) {
                                oldCodep.setFifteenUDate(newCodep.getFifteenUDate());
                            }
                        } else {
                            if (null != newCodep.getFifteenUDate()) {
                                oldCodep.setFifteenUDate(newCodep.getFifteenUDate());
                            }
                        }

                        if (null != oldCodep.getSixteenDate()) {
                            if (!oldCodep.getSixteenDate().equals(newCodep.getSixteenDate())) {
                                oldCodep.setSixteenDate(newCodep.getSixteenDate());
                            }
                        } else {
                            if (null != newCodep.getSixteenDate()) {
                                oldCodep.setSixteenDate(newCodep.getSixteenDate());
                            }
                        }

                        if (null != oldCodep.getTwentyFiveDate()) {
                            if (!oldCodep.getTwentyFiveDate().equals(newCodep.getTwentyFiveDate())) {
                                oldCodep.setTwentyFiveDate(newCodep.getTwentyFiveDate());
                            }
                        } else {
                            if (null != newCodep.getTwentyFiveDate()) {
                                oldCodep.setTwentyFiveDate(newCodep.getTwentyFiveDate());
                            }
                        }

                        if (null != oldCodep.getThirtyDate()) {
                            if (!oldCodep.getThirtyDate().equals(newCodep.getThirtyDate())) {
                                oldCodep.setThirtyDate(newCodep.getThirtyDate());
                            }
                        } else {
                            if (null != newCodep.getThirtyDate()) {
                                oldCodep.setThirtyDate(newCodep.getThirtyDate());
                            }
                        }

                        if (null != oldCodep.getPartAtrFlag()) {
                            if (!oldCodep.getPartAtrFlag().equals(newCodep.getPartAtrFlag())) {
                                oldCodep.setPartAtrFlag(newCodep.getPartAtrFlag());
                            }
                        } else {
                            if (null != newCodep.getPartAtrFlag()) {
                                oldCodep.setPartAtrFlag(newCodep.getPartAtrFlag());
                            }
                        }

                        if (null != oldCodep.getRealStrucFlag()) {
                            if (!oldCodep.getRealStrucFlag().equals(newCodep.getRealStrucFlag())) {
                                oldCodep.setRealStrucFlag(newCodep.getRealStrucFlag());
                            }
                        } else {
                            if (null != newCodep.getRealStrucFlag()) {
                                oldCodep.setRealStrucFlag(newCodep.getRealStrucFlag());
                            }
                        }

                        if (null != oldCodep.getDrawingFlag()) {
                            if (!oldCodep.getDrawingFlag().equals(newCodep.getDrawingFlag())) {
                                oldCodep.setDrawingFlag(newCodep.getDrawingFlag());
                            }
                        } else {
                            if (null != newCodep.getDrawingFlag()) {
                                oldCodep.setDrawingFlag(newCodep.getDrawingFlag());
                            }
                        }

                        if (null != oldCodep.getSheetsFlag()) {
                            if (!oldCodep.getSheetsFlag().equals(newCodep.getSheetsFlag())) {
                                oldCodep.setSheetsFlag(newCodep.getSheetsFlag());
                            }
                        } else {
                            if (null != newCodep.getSheetsFlag()) {
                                oldCodep.setSheetsFlag(newCodep.getSheetsFlag());
                            }
                        }

                        if (null != oldCodep.getMaterialsFlag()) {
                            if (!oldCodep.getMaterialsFlag().equals(newCodep.getMaterialsFlag())) {
                                oldCodep.setMaterialsFlag(newCodep.getMaterialsFlag());
                            }
                        } else {
                            if (null != newCodep.getMaterialsFlag()) {
                                oldCodep.setMaterialsFlag(newCodep.getMaterialsFlag());
                            }
                        }

                        if (null != oldCodep.getUsageAttFlag()) {
                            if (!oldCodep.getUsageAttFlag().equals(newCodep.getUsageAttFlag())) {
                                oldCodep.setUsageAttFlag(newCodep.getUsageAttFlag());
                            }
                        } else {
                            if (null != newCodep.getUsageAttFlag()) {
                                oldCodep.setUsageAttFlag(newCodep.getUsageAttFlag());
                            }
                        }

                        if (null != oldCodep.getModelImpByOdm()) {
                            if (!oldCodep.getModelImpByOdm().equals(newCodep.getModelImpByOdm())) {
                                oldCodep.setModelImpByOdm(newCodep.getModelImpByOdm());
                            }
                        } else {
                            if (null != newCodep.getModelImpByOdm()) {
                                oldCodep.setModelImpByOdm(newCodep.getModelImpByOdm());
                            }
                        }

                        if (null != oldCodep.getImpactFlag()) {
                            if (!oldCodep.getImpactFlag().equals(newCodep.getImpactFlag())) {
                                oldCodep.setImpactFlag(newCodep.getImpactFlag());
                            }
                        } else {
                            if (null != newCodep.getImpactFlag()) {
                                oldCodep.setImpactFlag(newCodep.getImpactFlag());
                            }
                        }

                        if (null != oldCodep.getOperator()) {
                            if (!oldCodep.getOperator().equals(newCodep.getOperator())) {
                                oldCodep.setOperator(newCodep.getOperator());
                            }
                        } else {
                            if (null != newCodep.getOperator()) {
                                oldCodep.setOperator(newCodep.getOperator());
                            }
                        }

                        if (null != oldCodep.getOperatorManager()) {
                            if (!oldCodep.getOperatorManager().equals(newCodep.getOperatorManager())) {
                                oldCodep.setOperatorManager(newCodep.getOperatorManager());
                            }
                        } else {
                            if (null != newCodep.getOperatorManager()) {
                                oldCodep.setOperatorManager(newCodep.getOperatorManager());
                            }
                        }

                        if (null != oldCodep.getOdmRequester()) {
                            if (!oldCodep.getOdmRequester().equals(newCodep.getOdmRequester())) {
                                oldCodep.setOdmRequester(newCodep.getOdmRequester());
                            }
                        } else {
                            if (null != newCodep.getOdmRequester()) {
                                oldCodep.setOdmRequester(newCodep.getOdmRequester());
                            }
                        }

                        if (null != oldCodep.getUnitCode()) {
                            if (!oldCodep.getUnitCode().equals(newCodep.getUnitCode())) {
                                oldCodep.setUnitCode(newCodep.getUnitCode());
                            }
                        } else {
                            if (null != newCodep.getUnitCode()) {
                                oldCodep.setUnitCode(newCodep.getUnitCode());
                            }
                        }

                        if (null != oldCodep.getUnitDescription()) {
                            if (!oldCodep.getUnitDescription().equals(newCodep.getUnitDescription())) {
                                oldCodep.setUnitDescription(newCodep.getUnitDescription());
                            }
                        } else {
                            if (null != newCodep.getUnitDescription()) {
                                oldCodep.setUnitDescription(newCodep.getUnitDescription());
                            }
                        }

                        if (null != oldCodep.getInitiativeCode()) {
                            if (!oldCodep.getInitiativeCode().equals(newCodep.getInitiativeCode())) {
                                oldCodep.setInitiativeCode(newCodep.getInitiativeCode());
                            }
                        } else {
                            if (null != newCodep.getInitiativeCode()) {
                                oldCodep.setInitiativeCode(newCodep.getInitiativeCode());
                            }
                        }

                        if (null != oldCodep.getDrawing()) {
                            if (!oldCodep.getDrawing().equals(newCodep.getDrawing())) {
                                oldCodep.setDrawing(newCodep.getDrawing());
                            }
                        } else {
                            if (null != newCodep.getDrawing()) {
                                oldCodep.setDrawing(newCodep.getDrawing());
                            }
                        }

                        if (null != oldCodep.getDrawingRelease()) {
                            if (!oldCodep.getDrawingRelease().equals(newCodep.getDrawingRelease())) {
                                oldCodep.setDrawingRelease(newCodep.getDrawingRelease());
                            }
                        } else {
                            if (null != newCodep.getDrawingRelease()) {
                                oldCodep.setDrawingRelease(newCodep.getDrawingRelease());
                            }
                        }

                        if (null != oldCodep.getReleaseDate()) {
                            if (!oldCodep.getReleaseDate().equals(newCodep.getReleaseDate())) {
                                oldCodep.setReleaseDate(newCodep.getReleaseDate());
                            }
                        } else {
                            if (null != newCodep.getReleaseDate()) {
                                oldCodep.setReleaseDate(newCodep.getReleaseDate());
                            }
                        }

                        try {
                            grayLogLogger.info("OLD CODEP VALUES REFRESHED: " + oldCodep);
//                            System.out.println("OLD CODEP REFRESHED:  " + oldCodep);
                            codepRepository.save(oldCodep);
                        } catch (Exception e) {
                            System.out.println("HATALI KAYIT : " + oldCodep);
                            e.printStackTrace();
                        }
                    }
                } else {
                    // ODM YAYINI

                    /*sendMailListForCodep.add(newCodep);

                    if (newCodep.getModel().equals("3562") || newCodep.getModel().equals("2251") || newCodep.getModel().equals("2631") || newCodep.getModel().equals("6360")) {
                        if (newCodep.getFmt() != null && !newCodep.getFmt().equals("") && !newCodep.getFmt().equals("MG") && !newCodep.getFmt().equals("SD")) {
                            if (!newCodep.getChangeTypeDesc().equals("SOPPRESSO")) {
                                if (!newCodep.getDrawing().equals("N")) {
                                    if (!newCodep.getState().equals("30")) {
                                        sendMail(newCodep);
                                    }
                                }
                            }
                        }
                    }*/

                    try {
                        grayLogLogger.info("NEW CODEP VALUES ADDED: " + newCodep);
                        codepRepository.save(newCodep);
//                        System.out.println("NEW CODEP VALUES ADDED : " + newCodep);
                    } catch (Exception e) {
                        System.out.println("HATALI KAYIT : " + newCodep);
                        e.printStackTrace();
                    }
                }
            } else {
                try {
                    grayLogLogger.warn("There is an error bacause of one of the id filed is null!! :  " + newCodep);
//                    System.out.println("There is an error because of id field is null!! : " + newCodep);
                    codepRepository.saveAll(codeps);
                } catch (Exception e) {
                    System.out.println("HATALI KAYIT : " + codeps);
                    e.printStackTrace();
                }
            }
        });

        // DELETING FLAG

        /*String progress = "COMPLETA";
        String lates25Date = ZonedDateTime.now().minusDays(1).format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        List<CodepFile> codepFiles = codepFileRepository.findAllByProgressAndLates25DateAndLates25DateIsNotNull(progress, lates25Date);

        if (codepFiles.size() > 0) {
            codepFiles.stream()
                    .filter(codepFile -> codepFile.getMod().equals("3562") || codepFile.getMod().equals("2251") || codepFile.getMod().equals("2631") || codepFile.getMod().equals("6360"))
                    .forEach(codepFile -> {
                        // ODM Yayını

                        if (sendMailListForCodep.size() > 0) {
                            sendMailListForCodep.stream()
                                    .filter(newCodep -> newCodep.getModel().equals(codepFile.getMod()) && newCodep.getModel().equals(codepFile.getOdm()))
                                    .forEach(newCodep -> {
                                        if (newCodep.getFmt() != null && !newCodep.getFmt().equals("") && !newCodep.getFmt().equals("MG") && !newCodep.getFmt().equals("SD")) {
                                            if (!newCodep.getChangeTypeDesc().equals("SOPPRESSO")) {
                                                if (!newCodep.getDrawing().equals("N")) {
                                                    if (!newCodep.getState().equals("30")) {
                                                        sendMail(newCodep);
                                                    }
                                                }
                                            }
                                        }
                                    });
                        }


                        // Tüm TC04 verilerine bakarak silinecek kayıtları bul
                        List<Codep> codepListForTC01 = codepRepository.findAllByModelAndOdmNo(codepFile.getMod(), codepFile.getOdm());
                        if (null != codepListForTC01 && codepListForTC01.size() > 0) {
                            List<Codep> addDeletedFlagForCodep = new ArrayList<>();
                            codepListForTC01.stream().filter(codep -> codep.getState().equals("00")).forEach(codep -> {
                                codep.setDeletedFlag(Boolean.TRUE);
                                addDeletedFlagForCodep.add(codep);
                            });
                            if (addDeletedFlagForCodep.size() > 0) {
                                codepRepository.saveAll(addDeletedFlagForCodep);
                            }
                        }
                    });
        }*/
    }

    // SEND MAIL

    @Async
    public void sendMail(Codep codep) {
        if (null != codep) {
            String model = codep.getModel();
            String odmNo = codep.getOdmNo();
            String partNo = codep.getPartNr();
            String releaseDate = codep.getReleaseDate();
            String twentyFiveDate = codep.getTwentyFiveDate();
            String releaseStatus = null;

            if (null != releaseDate) {
                if (releaseDate.contains("39991231")) {
                    releaseStatus = "yayını+beklenmektedir.";
                } else {
                    releaseStatus = releaseDate + "+tarihinde+yayınlanmıştır.";
                }
            }

            String text;
            String subject = "ODM+Resim+Yayını";
            StringBuilder to = new StringBuilder();
            StringBuilder cc = new StringBuilder();
            String from = "lcm@tofas.com.tr";

            cc.append("t53270@tofas.com.tr");

            to.append("t53270@tofas.com.tr");
            to.append(",").append("t32953@tofas.com.tr");
            to.append(",").append("t07365@tofas.com.tr");

            text = "+Sn.+İlgili,%0D+" + model + "+model+" + odmNo + "+numaralı+ODM+" +
                    twentyFiveDate + "+tarihinde+kapanmıştır.+" +
                    partNo + "+nolu+resim+" + releaseStatus +
                    "%0D%0D+Bilgilerinize,%0D+İyi+çalışmalar,%0D%0D+LCM+Mail+Service";

            String url = this.generateMailUrl(from, to.toString(), cc.toString(), subject, text);
            this.mailServiceConnection(url);
        }
    }

    private void mailServiceConnection(String url) {
        try {
            HttpPost postRequest = new HttpPost(url);
            postRequest.setHeader("X-CSRF-TOKEN", "YB5BYMLAXoPySbbBOHSx");
            postRequest.setHeader("Content-Type", "text/html; charset=utf-8");
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpResponse response = httpClient.execute(postRequest);
            BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));
            while (br.readLine() != null) {
                System.out.println(br.readLine());
            }
            httpClient.getConnectionManager().shutdown();
        } catch (Exception e) {
            grayLogLogger.error("Mail Service Connection Error: ", e);
        }
    }

    private String generateMailUrl(String from, String to, String cc, String subject, String text) {
        if (null != cc) {
            return sendMailWithCcAndToArray +
                    "&from=" + from +
                    "&to=" + to +
                    "&cc=" + cc +
                    "&subject=" + subject +
                    "&text=" + text;
        } else {
            return sendMailWithToArray +
                    "&from=" + from +
                    "&to=" + to +
                    "&subject=" + subject +
                    "&text=" + text;
        }
    }
}
